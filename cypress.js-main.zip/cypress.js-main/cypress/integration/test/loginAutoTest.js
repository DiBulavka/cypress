describe('Проверка форме логина', function () {

   it('Позитивный кейс(верный логин и пароль)', function () {
   	cy.visit('https://vk.com/');
   	cy.get('#index_email').type('mail');
   	cy.get('.VkIdForm__form > .FlatButton > .FlatButton__in > .FlatButton__content').click();
   	cy.get(':nth-child(1) > .vkc__TextField__wrapper > .vkc__TextField__input').type('password');
   	cy.get('.vkuiButton__content > span').click();
    })
})
