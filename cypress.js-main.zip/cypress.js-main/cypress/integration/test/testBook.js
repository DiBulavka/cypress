describe('Поиск книги', function () {

   it('Позитивный кейс(верный логин и пароль)', function () {
   	cy.visit('https://naukabooks.ru/');
   	cy.get('.se-link').click();
   	cy.get('.nb-header-search-input').click().type('Толстой{Enter}');
   	cy.get(':nth-child(3) > .footer__list > :nth-child(6) > a > span').click();
   	cy.go('back');
    })
})
